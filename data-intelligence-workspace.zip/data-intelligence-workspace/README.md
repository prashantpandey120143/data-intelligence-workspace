# Data Intelligence Workspace

A Databricks-native Streamlit application for importing one or many CSV, TSV, XLSX, XLS, Parquet, or JSON files and automatically producing practical analytics.

## What it does
- Persistent multi-file storage in a Unity Catalog Volume
- Automatic profiling and semantic field detection
- Multiple candidate measures, dimensions, and date fields
- Manual override of measures, group-by field, date field, aggregation, and top-N
- KPI summary
- Grouped comparison chart
- Time-series trend chart when a date field exists
- Measure comparison
- Distribution histogram
- Missingness and duplicate analysis
- IQR-based outlier detection
- Pairwise numeric correlations
- Deterministic business recommendations
- Excel export with data, summary, field intelligence, trends/groups, outliers, correlations, and recommendations
- Duplicate upload protection by content hash

## Storage
The app expects an app resource with resource key `volume` pointing to:
`/Volumes/workspace/data_intelligence/app_files`
with `Can read and write` permission.

The app creates these subdirectories through the Databricks SDK Files API:
- `uploads/`
- `metadata/`
- `exports/`

## Create storage once
```sql
CREATE SCHEMA IF NOT EXISTS workspace.data_intelligence;
CREATE VOLUME IF NOT EXISTS workspace.data_intelligence.app_files;
```

## Source files
- `app.py` - main application
- `app.yaml` - Databricks App runtime configuration
- `requirements.txt` - pinned/runtime dependencies
- `00_create_storage.sql` - one-time storage setup
- `DEPLOYMENT.md` - deployment checklist

## Current analysis limits
- The application caps in-session analysis at 500,000 rows to stay practical on Free Edition app compute.
- Upload control defaults to 50 MB and can be adjusted in the sidebar up to 200 MB, but actual workable size depends on the file format and memory required to parse it.
- Automatic analysis is heuristic/statistical. Manual mode is provided to override inferred choices.
